const grpc = require('grpc');
const protoLoader = require('@grpc/proto-loader');
const packageDefinition = protoLoader.loadSync('AirConditioningDevice.proto', 'keepCase');
var off =   'Off';
var on =   'On';


var AirConditioningDeviceproto = grpc.loadPackageDefinition(packageDefinition);

var AirConditioningDevice = [{
    deviceId: 1,
    name: 'Device1',
    location: 'room1',
    status: 'On',
    newTempature: 11
},
{
    deviceId: 2,
    name: 'Device2',
    location: 'room2',
    status: 'off',
    newTempature: 11
},
{
    deviceId: 3,
    name: 'Device3',
    location: 'room3',
    status: 'off',
    newTempature: 11
},
{
    deviceId: 4,
    name: 'Device4',
    location: 'room4',
    status: 'off',
    newTempature: 11
},
{
    deviceId: 5,
    name: 'Device5',
    location: 'room5',
    status: 'On',
    newTempature: 11
}];

var newTemp = 0;
var server = new grpc.Server();
server.addService(AirConditioningDeviceproto.AirConditioningDevice.Airconditioning_service.service,{
    currentDetails: function(call, callback){
        console.log(call.request)
        for(var i =0; i <AirConditioningDevice.length; i++){
             if(AirConditioningDevice[i].deviceId == call.request.deviceId){
                 console.log(call.request.deviceId);
                 return callback(null, {airConditioning:AirConditioningDevice[i]});
                
             }
             console.log(callback);
        }
       
        callback({
            code: grpc.status.NOT_FOUND,
            details: 'Not found'
        });
    },
    setTemp: function(call, callback){
        console.log(call.request)
        var NEW = call.request.newTemp;
        for(var i =0; i <AirConditioningDevice.length; i++){
             if(AirConditioningDevice[i].deviceId == call.request.deviceId){
                 console.log(call.request.deviceId);
                 AirConditioningDevice[i].newTempature = NEW
                 return callback(null, {airConditioning:AirConditioningDevice[i]});
                
             }
             console.log(callback);
        }
       
        callback({
            code: grpc.status.NOT_FOUND,
            details: 'Not found'
        });
     

    },
    setOff: function(call, callback){
        console.log(call.request)
        for(var i =0; i <AirConditioningDevice.length; i++){
            if(AirConditioningDevice[i].status = on)
             if(AirConditioningDevice[i].deviceId == call.request.deviceId){
                 console.log(call.request.deviceId);
                 AirConditioningDevice[i].status = off
                 return callback(null, {airConditioning:AirConditioningDevice[i]});
                
             }
             console.log(callback);
        }
       
        callback({
            code: grpc.status.NOT_FOUND,
            details: 'Not found'
        });
        
    },
    setOn: function(call, callback){
        console.log(call.request)
        for(var i =0; i <AirConditioningDevice.length; i++){
            if(AirConditioningDevice[i].status = off)
             if(AirConditioningDevice[i].deviceId == call.request.deviceId){
                 console.log(call.request.deviceId);
                 AirConditioningDevice[i].status = on
                 return callback(null, {airConditioning:AirConditioningDevice[i]});
                
             }
             console.log(callback);
        }
       
        callback({
            code: grpc.status.NOT_FOUND,
            details: 'Not found'
        });
        
    }
    
    
});

server.bind('localhost:3000', grpc.ServerCredentials.createInsecure());
server.start();